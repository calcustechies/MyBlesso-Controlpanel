$(function(){
	 $("#ecommercezoom").ecommercezoom({
		   autoPlay: false,
	   });
	 $("#ecommercezoom").removeClass('hidden')
});