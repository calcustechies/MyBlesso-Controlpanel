 $('.dropify').dropify({
	messages: {
		'default': 'Upload image',
		'replace': 'Upload image',
		'remove': 'Remove',
		'error': 'Ooops, something wrong appended.'
	},
	error: {
		'fileSize': 'The file size is too big (2M max).'
	}
});
 $('.dropify1').dropify({
	messages: {
		'default': '<i class="fa fa-upload"></i> Upload Resume',
		'replace': '<i class="fa fa-upload"></i> Upload Resume'
	}
});