<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class JobCtrl extends CI_Controller {

    // DISPLAY JOB DETAILS  IN DATA TABLE
    public function JobViewdetails()
    {
        
        $apiPrefix = $this->config->item('url_prefix');
        $result = $this->ctlib->url($apiPrefix .'DisplayPostedJobsWithFilter/0/0/0/0/0/0');
        //print_r($result);

        $draw = intval($this->input->get("draw"));
         // $start = intval($this->input->get("start"));
         // $length = intval($this->input->get("length"));
 
         //$HNDatas = $this->hospitallib->ViewHospitalNetworks();
         $viewjobdetails = json_decode($result, true);
         $countOfjob= count($viewjobdetails['Display Jobs']);
 
         
         $data = [];
         $k=1;
 
         for ($i = 0; $i < $countOfjob; $i++) {
             $JobPostID = $viewjobdetails['Display Jobs'][$i]['JobPostID'];
             $JobPostTitle = $viewjobdetails['Display Jobs'][$i]['JobPostTitle'];
             $jobTypeName = $viewjobdetails['Display Jobs'][$i]['jobTypeName'];
             $DistrictName = $viewjobdetails['Display Jobs'][$i]['DistrictName'];
             $JobPostLocality = $viewjobdetails['Display Jobs'][$i]['JobPostLocality'];
             $userQualification = $viewjobdetails['Display Jobs'][$i]['userQualification'];
             $JobPostHiringFor = $viewjobdetails['Display Jobs'][$i]['JobPostHiringFor'];
             $userFirstName = $viewjobdetails['Display Jobs'][$i]['userFirstName'];
             $userLastName = $viewjobdetails['Display Jobs'][$i]['userLastName'];
             //$ClubName = $viewjobdetails['Display Jobs'][$i]['ClubName'];
           
             //$eventdate=date('Y-m-d', strtotime($eventsDateTime) );
             
           
             
 
            
 
             $data[] = array(
                 $k,
                 $jobTypeName,
                 $DistrictName,
                 $JobPostLocality,
                 $JobPostTitle,
                 $JobPostHiringFor
              
             );
                $k++;
         }
         $result = array(
             "draw" => $draw,
              "recordsTotal" => $countOfjob,
              "recordsFiltered" => $countOfjob,
              "data" => $data
          );
         echo json_encode($result);
         exit();
    }

}