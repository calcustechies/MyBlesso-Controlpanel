			<!--footer-->
			<footer class="footer">
				<div class="container">
					<div class="row align-items-center flex-row-reverse">
						<div class="col-md-12 col-sm-12 mt-3 mt-lg-0 text-center">
							 2020 © MYBLESSO.  Design & Develop by <a href="http://calcus.in/" target="_blank">Calcus Technologies Pvt. Ltd</a>
						</div>
					</div>  
				</div>
			</footer>
			<!-- End Footer-->
		</div>

		<!-- Back to top -->
		<a href="#top" id="back-to-top" ><i class="fa fa-rocket"></i></a>
		<!-- Dashboard Core -->
		
		<script src="<?php echo base_url();?>/assets/js/vendors/jquery-3.2.1.min.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/bootstrap-4.3.1-dist/js/popper.min.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>/assets/js/vendors/jquery.sparkline.min.js"></script>
		<script src="<?php echo base_url();?>/assets/js/vendors/selectize.min.js"></script>
		<script src="<?php echo base_url();?>/assets/js/vendors/jquery.tablesorter.min.js"></script>
		<script src="<?php echo base_url();?>/assets/js/vendors/circle-progress.min.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/rating/jquery.rating-stars.js"></script>
		<!--Counters -->
		<script src="<?php echo base_url();?>/assets/plugins/counters/counterup.min.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/counters/waypoints.min.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/counters/numeric-counter.js"></script>
		<!-- Fullside-menu Js-->
		<script src="<?php echo base_url();?>/assets/plugins/toggle-sidebar/sidemenu.js"></script>
		<!-- CHARTJS CHART -->
		<script src="<?php echo base_url();?>/assets/plugins/chart/Chart.bundle.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/chart/utils.js"></script>
		<!-- Custom scroll bar Js-->
		<script src="<?php echo base_url();?>/assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>
		<!-- ECharts Plugin -->
		<script src="<?php echo base_url();?>/assets/plugins/echarts/echarts.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/echarts/echarts.js"></script>
		<script src="<?php echo base_url();?>/assets/js/index1.js"></script>
		<!-- Custom Js-->
		<script src="<?php echo base_url();?>/assets/js/admin-custom.js"></script>

		<!-- Data tables -->
		<script src="<?php echo base_url();?>/assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url();?>/assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="<?php echo base_url();?>/assets/js/datatable.js"></script>

		<!-- datatable responsive -->
		<script type="text/javascript" language="javascript" src="//cdn.datatables.net/responsive/1.0.2/js/dataTables.responsive.js"></script>

	</body>
</html>