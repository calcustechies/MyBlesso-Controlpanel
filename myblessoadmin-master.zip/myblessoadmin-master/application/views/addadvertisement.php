
				<div class="app-content">
					<div class="side-app">
						<div class="page-header">
							<h4 class="page-title">ADVERTISEMENT</h4>
							<form class="form-horizontal" enctype="multipart/form-data" action="<?php echo base_url('InsertAdvertisement')?>" method="POST">
							<input type="submit" class="btn btn-primary" name="upload" value="SAVE"> 
                           
							
							
						</div>
					
								<div class="card">
									<div class="card-header">
										<h3 class="card-title"> ADD NEW ADVERTISEMENT</h3>


									</div>
									<div class="card-body">
										<div class="input-group mb-3">
											

											<div class="input-group mb-3">
												<label class="control-label col-md-3 col-sm-3 col-xs-3 mt-2">TITLE</label>
												<div class="col-md-9 col-sm-9 col-xs-9">
													<input type="text" class="form-control" name="advtitle">
													<span class=" form-control-feedback right" aria-hidden="true"></span>
												</div>
											</div>
											<div class="input-group mb-3">
												<label class="control-label col-md-3 col-sm-3 col-xs-3 mt-2">DESCRIPTION</label>
												<div class="col-md-9 col-sm-9 col-xs-9">
													<input type="text" class="form-control"  name="advdescription">
													<span class=" form-control-feedback right" aria-hidden="true"></span>
												</div>
											</div>
											<div class="input-group mb-3">
												<label class="control-label col-md-3 col-sm-3 col-xs-3 mt-2">LINK</label>
												<div class="col-md-9 col-sm-9 col-xs-9">
													<input type="text" class="form-control" name="advlink">
													<span class="form-control-feedback right" aria-hidden="true"></span>
												</div>
											</div>
											
											<div class="input-group mb-3">
											
											<div class="custom-file">
												<input type="file" name="a_img">
												<!-- <label class="custom-file-label">Choose file</label> -->
											</div>
									
									</div>


									
											

									

										
									</div>
								</div>
								
								

								
								</form>		
						</div>
					</div>
				</div>
			</div>
           