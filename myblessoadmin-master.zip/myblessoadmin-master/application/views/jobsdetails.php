

				<div class="app-content">
					<div class="side-app">
						<div class="page-header">
							<h4 class="page-title">Jobs Details</h4>
							

						</div>
						<div class="row">
							<div class="col-md-12 col-lg-12">
								<div class="card">
									<div class="card-header">
										<div class="card-title">Jobs Details</div>

									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="jobdetails" class="table table-striped table-bordered" >
												<thead>
													<tr>
														<th class="wd-15p">SL NO</th>
														<th class="wd-15p">JOB TYPE</th>
														<th class="wd-15p">DistrictName</th>
														<th class="wd-15p">PLACE</th>
														<th class="wd-15p">ROLE</th>
														<th class="wd-15p">COMPANY</th>
														<!-- <th class="wd-25p">ELIGIBILITY</th> -->
													</tr>

														
													
												</thead>
												<tbody>
												
														<!-- <tr>
																<td>
																	3265
																</td>
																
																<td>
																	<span>Full Time</span>
																</td>
																<td>Kerala</td>
																<td>Hard ware Technician</td>
																<td>Acme Corporation pvt ltd</td>
																<td>Any Graduate</td>
																
																
															</tr>
																<tr>
																<td>
																	3265
																</td>
																
																<td>
																	<span>Full Time</span>
																</td>
																<td>Kerala</td>
																<td>Hard ware Technician</td>
																<td>Acme Corporation pvt ltd</td>
																<td>Any Graduate</td>
																
																
															</tr>
																<tr>
																<td>
																	3265
																</td>
																
																<td>
																	<span>Full Time</span>
																</td>
																<td>Kerala</td>
																<td>Hard ware Technician</td>
																<td>Acme Corporation pvt ltd</td>
																<td>Any Graduate</td>
																
																
															</tr>
																 -->
													
												</tbody>
											</table>
										</div>
									</div>
									<!-- table-wrapper -->
								</div>
								<!-- section-wrapper -->
							</div>
					
					</div>
				</div>
			</div>
			<!--MAIN ENDS-->
			<input type="hidden" id="base" value="<?php echo base_url(); ?>">
				
			<script src="<?php echo base_url(); ?>assets/js/general/jobdetails.js"></script>		
			