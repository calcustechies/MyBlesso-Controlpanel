

				<div class="app-content">
					<div class="side-app">
						<div class="page-header">
							<h4 class="page-title">Company Details</h4>
							

						</div>
						<div class="row">
							<div class="col-md-12 col-lg-12">
								<div class="card">
									<div class="card-header">
										<div class="card-title">Company Details</div>

									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="example" class="table table-striped table-bordered" >
												<thead>
													<tr>
														<th class="wd-15p">SL NO</th>
														<th class="wd-15p">COMPANY NAME</th>
														<th class="wd-20p">ADDRESS</th>
														<th class="wd-15p">PLACE</th>
														<th class="wd-25p">PHONE NO</th>
													</tr>
													
													
													
												</thead>
												<tbody>
												
														<tr>
																<td>
																	3265
																</td>
																
																<td>
																	<span>calcus Technologies</span>
																</td>
																<td>abcdhgf,TCR</td>
																<td>Kerala</td>
																<td>12346578</td>	
															</tr>
															<tr>
																<td>
																	3265
																</td>
																
																<td>
																	<span>calcus Technologies</span>
																</td>
																<td>abcdhgf,TCR</td>
																<td>Kerala</td>
																<td>12346578</td>	
															</tr>
															<tr>
																<td>
																	3265
																</td>
																
																<td>
																	<span>calcus Technologies</span>
																</td>
																<td>abcdhgf,TCR</td>
																<td>Kerala</td>
																<td>12346578</td>	
															</tr>
														

													
												</tbody>
											</table>
										</div>
									</div>
									<!-- table-wrapper -->
								</div>
								<!-- section-wrapper -->
							</div>
					
					</div>
				</div>
			</div>
			<!--MAIN ENDS-->



				

