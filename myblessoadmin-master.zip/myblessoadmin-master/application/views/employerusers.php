

				<div class="app-content">
					<div class="side-app">
						<div class="page-header">
							<h4 class="page-title">Employer List</h4>
							

						</div>
						<div class="row">
							<div class="col-md-12 col-lg-12">
								<div class="card">
									<div class="card-header">
										<div class="card-title">Employer List</div>

									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="employerdetails" class="table table-striped table-bordered" >
												<thead>
													
													<tr>
														<th class="wd-10p">ID</th>
														<th class="wd-15p">NAME</th>
														<th class="wd-20p">DESIGNATION</th>
														<th class="wd-20p">PHONE NO</th>
														<th class="wd-15p">POSTS</th>
														<th class="wd-10p">REFERAL CODE</th>
														<!-- <th class="wd-20p">STATUS</th> -->
														<th class="wd-20p">LAST LOGIN</th>
														</tr>
													
												</thead>
												<tbody>
												
										

													
												</tbody>
											</table>
										</div>
									</div>
									<!-- table-wrapper -->
								</div>
								<!-- section-wrapper -->
							</div>
					
					</div>
				</div>
			</div>
			<!--MAIN ENDS-->


			<input type="hidden" id="base" value="<?php echo base_url(); ?>">
			<script src="<?php echo base_url(); ?>assets/js/general/employeruser.js"></script>




		